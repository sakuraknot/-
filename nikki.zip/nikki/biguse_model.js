var shoppingCart1 =  clone(shoppingCart);
var shoppingCart2 =  clone(shoppingCart);
shoppingCart1.clear();
shoppingCart2.clear();