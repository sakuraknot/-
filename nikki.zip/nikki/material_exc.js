﻿/*
var wspos=6000;
var wardrobe_a=wardrobe;
var wardrobe=function() {
	var ret = [];
	for (var i in wardrobe_a) {
		var tmp=wardrobe[i];
		if(i>=wspos) {continue;}
		ret.push(tmp);
	}
	return ret;
}();
*/
var manualScoring = {
	"競技場: 女王大人" : {'連身裙342':25600,},
	"競技場: 海邊派對的搭配" : {'連身裙063':22310,'下著430':11390},
	"競技場: 夏日物語" : {'連身裙808':22500,},
	"競技場: 辦公室明星" : {'連身裙259':26170,},
}
